#!/bin/sh
cd /usr/local/src/proot
make CC=gcc CFLAGS="-O2" 2>/dev/null || make CFLAGS="-O2"
cp -f proot /usr/local/bin/proot
echo "proot built: /usr/local/bin/proot"
