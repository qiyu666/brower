/* This file is auto-generated, edit at your own risk.  */
#ifndef CONFIG_H
#define CONFIG_H
#define VERSION v0.6.1
#define HAVE_READLINKAT
#endif /* CONFIG_H */
